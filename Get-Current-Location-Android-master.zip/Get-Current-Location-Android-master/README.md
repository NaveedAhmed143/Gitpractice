# Get-Current-Location-Android
get Current latitude and Longitude in android studio code.
